
document.getElementById("tos-link").addEventListener("click", function(e) {
    e.preventDefault();
    document.getElementById("tos-modal").style.display = "flex";
});
document.getElementById("close-tos").addEventListener("click", function() {
    document.getElementById("tos-modal").style.display = "none";
});
