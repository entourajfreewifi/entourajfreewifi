
function openTerms() {
    document.getElementById('terms-modal').style.display = 'block';
}

function closeTerms() {
    document.getElementById('terms-modal').style.display = 'none';
}

function submitForm() {
    const urlParams = new URLSearchParams(window.location.search);
    const token = urlParams.get('token');
    if (token) {
        document.getElementById('token').value = token;
        return true;
    } else {
        alert("Missing login token.");
        return false;
    }
}
